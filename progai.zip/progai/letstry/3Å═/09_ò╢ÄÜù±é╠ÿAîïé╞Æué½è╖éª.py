print('わたしは' + 'ネコ')
print('BMI値は' + str(25))
text_comment = 'AIプログラミングに' + 'Pythonは欠かせない！'
#置き換え前を表示
print(text_comment)
#置き換え後を表示
print(text_comment.replace('Python', 'パイソン'))
