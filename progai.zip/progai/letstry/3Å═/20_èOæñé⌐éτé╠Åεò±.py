import sys
print(len(sys.argv)) #組み込み関数「len」で受け取った引数の数がわかります
print(sys.argv[0]) #0番目はプログラム名
print(sys.argv[1]) #1番目は1つ目の引数の内容
