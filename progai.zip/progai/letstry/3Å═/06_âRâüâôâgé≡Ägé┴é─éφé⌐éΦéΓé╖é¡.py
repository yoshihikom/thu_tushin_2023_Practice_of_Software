MY_HEIGHT = 1.7 #身長[m]
MY_WEIGHT = 70 #体重[kg]

#BMI=体重[kg]÷(身長[m]×身長[m])
print(MY_WEIGHT / (MY_HEIGHT * MY_HEIGHT))
