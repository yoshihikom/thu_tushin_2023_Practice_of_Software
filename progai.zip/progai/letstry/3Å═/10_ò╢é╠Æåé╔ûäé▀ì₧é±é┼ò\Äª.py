MY_HEIGHT = 1.7
my_weight = 70
my_bmi = my_weight / (MY_HEIGHT * MY_HEIGHT)
print(f'体重は{my_weight}kg、身長は{MY_HEIGHT}m')
print(f'計算したBMI値は{my_bmi}でした。')
